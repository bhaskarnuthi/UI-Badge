import axios from "axios";
import React, { useState } from "react";
function Users() {
    const [name, setName] = useState("")
    const [mfgCompany, setMfgCompany] = useState("")
    const [price, setPrice] = useState("")
    const [quantity, setQuantity] = useState("")
    const updateName = (e) => {
        setName(e.target.value)
    }
    const updateMfgCompany = (e) => {
        setMfgCompany(e.target.value)
    }
    const updatePrice = (e) => {
        setPrice(e.target.value)
    }
    const updateQty = (e) => {
        setQuantity(e.target.value)
    }
    const handleAdd = () => {
        let id = new Date().getTime();
        const product = {
            id: id+1,
            name : name,
            mfgCompany : mfgCompany,
            price : price,
            quantity : quantity
        }
        axios.post('http://localhost:3000/products',product)
        .then(result => {
            console.log(result.data)
            alert("Product saved successfully!!!")
        })
        .catch(err => {
            console.log(err)
        })
    }
    return (
        <div>
            <h1>Add new items</h1>
            Item Name: <input onChange={updateName} value ={name} type="text" /><br/>
           Manufacturer company: <input onChange={updateMfgCompany} value ={mfgCompany} type="text" /><br/>
           Price per unit: <input onChange={updatePrice} value={price} type="text" /><br/>
           Quantity: <input onChange={updateQty} value={quantity} type="text" /><br/>
           <button onClick={handleAdd}>Add</button>
            {/* <input value ={name} onChange={(e)=>setName(e.target.value )} />
            <button onClick={handleAdd}>Add</button>
            {
                allData.map((val,i) =>
                <div>
                    <h1>{val}</h1>
                    <button className="edit">Edit</button>
                    <button className="delete" onClick={()=>handleDelete(i)}>Delete</button>
                </div>
                )
            } */}
        </div>
    )
}
export default Users









