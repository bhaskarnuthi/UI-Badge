import { Component } from "react";
import Card from "./Card";
class ProductDetails extends Component {
    constructor(props) {
        super(props)
    }
    render() {
        console.log("received:::",this.props.products)
        return(
            <div>
                    <Card data={product} />
                
            </div>
        )
    }
}
export default ProductDetails;






