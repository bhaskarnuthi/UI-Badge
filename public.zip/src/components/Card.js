import './Card.css';

const Card = (props) => {

    console.log("props:::",props.data)
    return(
        <div>
            {props.data.forEach(product => {
                return ( 
                    <div id='card'>
                        <p>Name: {product.name}</p>
                        <p>Manufacturer: {product.mfgCompany}</p>
                    </div>
                )
            })}
            
        </div>
    )
}

export default Card