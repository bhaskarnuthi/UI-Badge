import { useState } from "react"
import axios from "axios"
function Register() {
   const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
   const [confirmpassword, setConfirmPassword] = useState('')
    const handlename = (e) => {
        setName(e.target.value)
    }
    const handleEmail = (e)=> {
        setEmail(e.target.value)
    }
    const handlePassword = (e)=> {
        setPassword(e.target.value)
    }
    const handleConfirmPassword = (e)=> {
        setConfirmPassword(e.target.value)
    }
    const handleApi = () => {
        console.log(name,email, password, confirmpassword)
        let id = new Date().getTime();
        const user = {
            id: id+1,
            name : name,
            email : email,
            password : password,
            confirmpassword : confirmpassword
        }
        axios.post('http://localhost:3000/users',user)
        .then(result => {
            console.log(result.data)
        })
        .catch(err => {
            console.log(err)
        })
    }
    return (
        <div>
           <h1>SIGN UP page </h1>
           Name: <input onChange={handlename} value ={name} type="name" /> <br/>
           Email: <input onChange={handleEmail} value ={email} type="text" /> <br/>
           Password: <input onChange={handlePassword} value={password} type="text" /> <br/>
           ConfirmPassword: <input onChange={handleConfirmPassword} value={confirmpassword} type="text" /> <br/>
           <button onClick={handleApi}> Register </button>
        </div>
    )
}
export default Register









