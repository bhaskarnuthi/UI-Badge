import axios from "axios"
import { useState } from "react"
const Login = () => {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const handleEmail = (e)=> {
        setEmail(e.target.value)
    }
    const handlePassword = (e)=> {
        setPassword(e.target.value)
    }
    const handleLogin = () => {
        console.log("Login details",email, password)
        axios.get('http://localhost:3000/users')
        .then(result => {
            console.log(result.data)
            result.data.map(login => {
                if(login.email !== email && login.password !== password) {
                    alert("Please enter the valid credentials")
                } else {
                    alert("Logged in successfully")
                }
            })
        })
        .catch(err => {
            console.log(err)
        })
    }
    return(
        <div>
            <input type="text" onChange={handleEmail} value={email} placeholder="enter user name" /> <br />
            <input type="password" onChange={handlePassword} value={password} placeholder="enter password" /> <br/>
            <button onClick={handleLogin}>Login</button>
        </div>
    )
}
export default Login









